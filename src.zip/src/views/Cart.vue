<template>
  <div class="about">
    <h1>My Cart:</h1>
    <div v-if="cartData.length === 0">
      <p>The cart is empty!</p>
    </div>
    <div v-else style = "display: flex; justify-content: flex-start;">
    <p style = "margin-left: 50px;"><b>ITEM</b></p>
    <p style = "margin-left: 195px;"><b>#</b></p>
    </div>
    <div class="combinedCart">
      <div class="currrCart">
        <div class="currCart" v-for="item in cartData" :key="item">
          <a @click="removeFromCart(item)"><button class="auto" style = "display: inline-block; vertical-align: middle; margin: 10px 0;">X</button></a>
          <p style = "margin-left:20px;">{{item}}</p>
        </div>
      </div>
      <div class="currrCartNums">
        <div class="currCartNums" v-for="item in cartNumData" :key="item">
          <p style = "margin-left: 30px; margin-right: 30px;">{{item}}</p>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  computed: {
    cartData() {
      return this.$root.$data.cart;
    },
    cartNumData() {
      return this.$root.$data.itemNumbers;
    }
  },
  methods: {
    removeFromCart(itemName) {
      const index = this.$root.$data.cart.indexOf(itemName);
      if (index > -1) {
        this.$root.$data.cart.splice(index, 1);
        this.$root.$data.itemNumbers.splice(index, 1);
      }
      for (let i = 0; i < this.$root.$data.cart.length; i++) {
        console.log (this.$root.$data.cart[i]);
      }
    }
  }
}

</script>

<style scoped>
.auto {
  margin-left: auto;
}
.combinedCart {
  display: flex;
  justify-content: flex-start;
}
.currrCart {
  display: box;
  align-items: flex-start;

}
.currCart {
  width: 250px;
  display: flex;
  justify-content: flex-start;
  border: 1px solid purple;
}
.currrCartNums {
  display: box;
  align-items: flex-start;

}
.currCartNums {
  display: flex;
  justify-content: flex-start;
  border: 1px solid purple;
}
</style>
